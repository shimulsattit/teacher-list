<script>
  let currentStep = 1;
  showStep(currentStep);

  function showStep(stepNumber) {
    const steps = document.querySelectorAll('.step');
    steps.forEach(step => (step.style.display = 'none'));

    const currentStepElement = document.querySelector(`.step-${stepNumber}`);
    currentStepElement.style.display = 'block';

    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (stepNumber === 1) {
      prevBtn.style.display = 'none';
    } else if (stepNumber === steps.length) {
      nextBtn.innerHTML = 'Submit';
    } else {
      prevBtn.style.display = 'block';
      nextBtn.innerHTML = 'Next';
    }
  }

  function changeStep(stepChange) {
    // Perform validation here if needed before changing steps
    if (stepChange > 0 && !validateStep(currentStep)) {
      return;
    }

    currentStep += stepChange;
    showStep(currentStep);
  }

  function validateStep(stepNumber) {
    // Perform validation for each step here
    // Example: Check if required fields are filled, etc.
    return true; // Return true if validation passes, false otherwise
  }
</script>
